# frozen_string_literal: false
module Psych
  class Set < ::Hash
  end
end
